import {
  type Product,
  type InsertProduct,
  type Table,
  type InsertTable,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type CashRegister,
  type InsertCashRegister,
  products,
  tables,
  orders,
  orderItems,
  cashRegister
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Tables
  getTables(): Promise<Table[]>;
  getTable(id: number): Promise<Table | undefined>;
  createTable(table: InsertTable): Promise<Table>;
  updateTable(id: number, table: Partial<Table>): Promise<Table>;

  // Orders
  getOrders(): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: Partial<Order>): Promise<Order>;
  getOrdersByTable(tableId: number): Promise<Order[]>;

  // Order Items
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(item: InsertOrderItem): Promise<OrderItem>;
  updateOrderItem(id: number, item: Partial<OrderItem>): Promise<OrderItem>;
  deleteOrderItem(id: number): Promise<number>;

  // Cash Register
  getCashRegisterEntries(): Promise<CashRegister[]>;
  createCashRegisterEntry(entry: InsertCashRegister): Promise<CashRegister>;
}

export class DatabaseStorage implements IStorage {
  // Products
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  // Tables
  async getTables(): Promise<Table[]> {
    return await db.select().from(tables);
  }

  async getTable(id: number): Promise<Table | undefined> {
    const [table] = await db.select().from(tables).where(eq(tables.id, id));
    return table;
  }

  async createTable(table: InsertTable): Promise<Table> {
    const [newTable] = await db.insert(tables).values(table).returning();
    return newTable;
  }

  async updateTable(id: number, tableData: Partial<Table>): Promise<Table> {
    const [updated] = await db
      .update(tables)
      .set(tableData)
      .where(eq(tables.id, id))
      .returning();
    if (!updated) throw new Error("Table not found");
    return updated;
  }

  // Orders
  async getOrders(): Promise<Order[]> {
    return await db.select().from(orders);
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }

  async updateOrder(id: number, orderData: Partial<Order>): Promise<Order> {
    const [updated] = await db
      .update(orders)
      .set(orderData)
      .where(eq(orders.id, id))
      .returning();
    if (!updated) throw new Error("Order not found");
    return updated;
  }

  async getOrdersByTable(tableId: number): Promise<Order[]> {
    return await db.select().from(orders).where(eq(orders.tableId, tableId));
  }

  // Order Items
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }

  async createOrderItem(item: InsertOrderItem): Promise<OrderItem> {
    const [newItem] = await db.insert(orderItems).values(item).returning();
    return newItem;
  }

  async updateOrderItem(id: number, itemData: Partial<OrderItem>): Promise<OrderItem> {
    const [updated] = await db
      .update(orderItems)
      .set(itemData)
      .where(eq(orderItems.id, id))
      .returning();
    if (!updated) throw new Error("Order item not found");
    return updated;
  }

  async deleteOrderItem(id: number): Promise<number> {
    await db.delete(orderItems).where(eq(orderItems.id, id));
    return id;
  }

  // Cash Register
  async getCashRegisterEntries(): Promise<CashRegister[]> {
    return await db.select().from(cashRegister);
  }

  async createCashRegisterEntry(entry: InsertCashRegister): Promise<CashRegister> {
    const [newEntry] = await db.insert(cashRegister).values(entry).returning();
    return newEntry;
  }

  async clearCashRegisterEntries(): Promise<void> {
    await db.delete(cashRegister);
  }
}

export const storage = new DatabaseStorage();