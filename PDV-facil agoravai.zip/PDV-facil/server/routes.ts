import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProductSchema, insertOrderSchema, insertOrderItemSchema, insertCashRegisterSchema, insertTableSchema } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  // Products
  app.get("/api/products", async (_req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.post("/api/products", async (req, res) => {
    const parsed = insertProductSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    const product = await storage.createProduct(parsed.data);
    res.json(product);
  });

  // Tables
  app.get("/api/tables", async (_req, res) => {
    const tables = await storage.getTables();
    res.json(tables);
  });

  app.post("/api/tables", async (req, res) => {
    const parsed = insertTableSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    const table = await storage.createTable(parsed.data);
    res.json(table);
  });

  app.post("/api/tables/reset", async (_req, res) => {
    // Limpar todas as mesas existentes
    await db.delete(tables);
    
    // Criar 20 mesas numeradas
    const newTables = [];
    for (let i = 1; i <= 20; i++) {
      const table = await storage.createTable({
        number: i,
        isOccupied: false
      });
      newTables.push(table);
    }
    
    res.json(newTables);
  });

  app.patch("/api/tables/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const table = await storage.updateTable(id, req.body);
    res.json(table);
  });

  // Orders
  app.get("/api/tables/:tableId/orders", async (req, res) => {
    const tableId = parseInt(req.params.tableId);
    const orders = await storage.getOrdersByTable(tableId);
    res.json(orders);
  });

  app.post("/api/orders", async (req, res) => {
    const parsed = insertOrderSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    const order = await storage.createOrder(parsed.data);
    res.json(order);
  });

  app.patch("/api/orders/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const order = await storage.updateOrder(id, req.body);
    res.json(order);
  });

  // Order Items
  app.get("/api/orders/:orderId/items", async (req, res) => {
    const orderId = parseInt(req.params.orderId);
    const items = await storage.getOrderItems(orderId);
    res.json(items);
  });

  app.post("/api/order-items", async (req, res) => {
    const parsed = insertOrderItemSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    const item = await storage.createOrderItem(parsed.data);
    res.json(item);
  });

  app.delete("/api/order-items/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteOrderItem(id);
    res.json({ success: true });
  });

  // Cash Register
  app.get("/api/cash-register", async (_req, res) => {
    const entries = await storage.getCashRegisterEntries();
    res.json(entries);
  });

  app.post("/api/cash-register", async (req, res) => {
    const { type, amount, notes, clearTransactions } = req.body;
    const parsed = insertCashRegisterSchema.safeParse({ type, amount, notes });
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error });
      return;
    }
    
    if (type === 'close' && clearTransactions) {
      await storage.clearCashRegisterEntries();
    }
    
    const entry = await storage.createCashRegisterEntry(parsed.data);
    res.json(entry);
  });

  const httpServer = createServer(app);
  return httpServer;
}