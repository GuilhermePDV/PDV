import { pgTable, text, serial, integer, decimal, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  category: text("category").notNull(),
});

export const tables = pgTable("tables", {
  id: serial("id").primaryKey(),
  number: integer("number").notNull(),
  name: text("name"),
  isOccupied: boolean("is_occupied").notNull().default(false),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  tableId: integer("table_id").notNull(),
  status: text("status").notNull(), // 'open', 'closed'
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  paymentMethod: text("payment_method"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
});

export const cashRegister = pgTable("cash_register", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'open', 'close', 'sale', 'withdrawal'
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertProductSchema = createInsertSchema(products);
export const insertTableSchema = createInsertSchema(tables);

// Customizando o schema de inserção de pedidos para lidar corretamente com campos opcionais
export const insertOrderSchema = z.object({
  tableId: z.number(),
  status: z.string(),
  total: z.string(),
  paymentMethod: z.string().nullable().optional(),
});

export const insertOrderItemSchema = createInsertSchema(orderItems);
export const insertCashRegisterSchema = createInsertSchema(cashRegister);

// Types
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Table = typeof tables.$inferSelect;
export type InsertTable = z.infer<typeof insertTableSchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;

export type CashRegister = typeof cashRegister.$inferSelect;
export type InsertCashRegister = z.infer<typeof insertCashRegisterSchema>;