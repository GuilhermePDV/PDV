import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import OrderForm from "./OrderForm";
import { type Table } from "@shared/schema";
import { Users, Plus, Edit2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TableGridProps {
  tables: Table[];
}

export default function TableGrid({ tables }: TableGridProps) {
  const { toast } = useToast();
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);
  const [editingTable, setEditingTable] = useState<Table | null>(null);
  const [tableName, setTableName] = useState("");

  const createTableMutation = useMutation({
    mutationFn: async () => {
      // Get the next table number
      const nextTableNumber = tables.length > 0 
        ? Math.max(...tables.map(t => t.number)) + 1 
        : 1;

      await apiRequest("POST", "/api/tables", {
        number: nextTableNumber,
        isOccupied: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
    },
  });

  const updateTableMutation = useMutation({
    mutationFn: async ({ id, name }: { id: number; name: string }) => {
      await apiRequest("PATCH", `/api/tables/${id}`, { name });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      setEditingTable(null);
      setTableName("");
      toast({
        title: "Mesa atualizada",
        description: "O nome da mesa foi atualizado com sucesso.",
      });
    },
  });

  const deleteTableMutation = useMutation({
    mutationFn: async (tableId: number) => {
      const response = await apiRequest("DELETE", `/api/tables/${tableId}`);
      if (!response.ok) {
        throw new Error("Erro ao remover mesa");
      }
      return tableId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      setSelectedTable(null);
      toast({
        title: "Mesa removida",
        description: "A mesa foi removida com sucesso.",
      });
    },
  });

  const toggleTableMutation = useMutation({
    mutationFn: async (tableId: number) => {
      const table = tables.find((t) => t.id === tableId);
      if (!table) return;

      if (table.isOccupied) {
        return await apiRequest("PATCH", `/api/tables/${tableId}`, {
          isOccupied: false,
        });
      } else {
        return await apiRequest("PATCH", `/api/tables/${tableId}`, {
          isOccupied: true,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      toast({
        title: "Status da mesa atualizado",
        description: "O status da mesa foi atualizado com sucesso.",
      });
    },
  });

  return (
    <>
      <div className="mb-4">
        <Button 
          onClick={() => createTableMutation.mutate()} 
          className="w-full md:w-auto"
        >
          <Plus className="h-4 w-4 mr-2" />
          Adicionar Nova Mesa
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {tables.map((table) => (
          <Card
            key={table.id}
            className={table.isOccupied ? "border-primary" : ""}
          >
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="font-semibold">{table.name || `Mesa ${table.number}`}</h3>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setEditingTable(table);
                      setTableName(table.name || "");
                    }}
                  >
                    <Edit2 className="h-4 w-4" />
                  </Button>

                  <Users className="h-4 w-4 text-muted-foreground" />
                </div>
              </div>

              <div className="space-y-2">
                <Button
                  variant={table.isOccupied ? "destructive" : "default"}
                  className="w-full"
                  onClick={() => toggleTableMutation.mutate(table.id)}
                >
                  {table.isOccupied ? "Liberar Mesa" : "Ocupar Mesa"}
                </Button>

                {table.isOccupied && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setSelectedTable(table)}
                  >
                    Gerenciar Pedido
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!selectedTable} onOpenChange={() => setSelectedTable(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              Pedido da Mesa {selectedTable?.number}
              {selectedTable?.name && ` - ${selectedTable.name}`}
            </DialogTitle>
          </DialogHeader>
          {selectedTable && <OrderForm tableId={selectedTable.id} />}
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingTable} onOpenChange={() => setEditingTable(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Mesa {editingTable?.number}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Nome da Mesa</Label>
              <Input
                value={tableName}
                onChange={(e) => setTableName(e.target.value)}
                placeholder="Ex: Área externa"
              />
            </div>
            <Button
              className="w-full"
              onClick={() => {
                if (editingTable) {
                  updateTableMutation.mutate({
                    id: editingTable.id,
                    name: tableName,
                  });
                }
              }}
            >
              Salvar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}