import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Home,
  Grid2X2,
  DollarSign,
  BarChart3,
  Package,
} from "lucide-react";

export default function MainNav() {
  const [location] = useLocation();

  const links = [
    { href: "/", label: "Início", icon: Home },
    { href: "/tables", label: "Mesas", icon: Grid2X2 },
    { href: "/products", label: "Produtos", icon: Package },
    { href: "/cash-register", label: "Caixa", icon: DollarSign },
    { href: "/reports", label: "Relatórios", icon: BarChart3 },
  ];

  return (
    <nav className="border-b">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center space-x-4 sm:space-x-8">
          {links.map(({ href, label, icon: Icon }) => (
            <Link key={href} href={href}>
              <a
                className={cn(
                  "flex items-center space-x-2 text-sm font-medium transition-colors hover:text-primary",
                  location === href
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
              >
                <Icon className="h-4 w-4" />
                <span>{label}</span>
              </a>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}