import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { useToast } from "../hooks/use-toast"; // Corrected import path
import { Trash2Icon } from "lucide-react";

interface OrderFormProps {
  tableId: number;
}

export default function OrderForm({ tableId }: OrderFormProps) {
  const { toast } = useToast();
  const [selectedProduct, setSelectedProduct] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [searchTerm, setSearchTerm] = useState("");

  const { data: products } = useQuery({
    queryKey: ["/api/products"],
  });

  const filteredProducts = searchTerm
    ? products?.filter((product: any) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : products;


  const { data: orders } = useQuery({
    queryKey: [`/api/tables/${tableId}/orders`],
  });

  const currentOrder = orders?.find((o: any) => o.status === "open");

  const { data: orderItems } = useQuery({
    queryKey: [`/api/orders/${currentOrder?.id}/items`],
    enabled: !!currentOrder,
  });

  const createOrderMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/orders", {
        tableId: tableId,
        status: "open",
        total: "0.00",
        paymentMethod: null
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erro ao criar pedido");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tables/${tableId}/orders`] });
      toast({
        title: "Pedido criado",
        description: "Um novo pedido foi criado para esta mesa.",
      });
    },
    onError: (error) => {
      console.error("Erro ao criar pedido:", error);
      toast({
        title: "Erro",
        description: "Não foi possível criar o pedido. Por favor, tente novamente.",
        variant: "destructive",
      });
    },
  });

  const addItemMutation = useMutation({
    mutationFn: async () => {
      const product = products?.find((p: any) => p.id === parseInt(selectedProduct));
      if (!product) throw new Error("Produto não encontrado");

      await apiRequest("POST", "/api/order-items", {
        orderId: currentOrder.id,
        productId: product.id,
        quantity: parseInt(quantity),
        price: product.price,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/orders/${currentOrder?.id}/items`] });
      setSelectedProduct("");
      setQuantity("1");
      setSearchTerm(""); //added to clear search after adding item
      toast({
        title: "Item adicionado",
        description: "O item foi adicionado ao pedido.",
      });
    },
    onError: (error) => {
      console.error("Erro ao adicionar item:", error);
      toast({
        title: "Erro",
        description: "Não foi possível adicionar o item ao pedido.",
        variant: "destructive",
      });
    },
  });

  const closeOrderMutation = useMutation({
    mutationFn: async () => {
      const total = orderItems?.reduce(
        (acc: number, item: any) => acc + item.quantity * Number(item.price),
        0,
      );

      // Primeiro fechar o pedido
      await apiRequest("PATCH", `/api/orders/${currentOrder.id}`, {
        status: "closed",
        total: total.toFixed(2),
      });

      // Depois registrar a venda no caixa
      await apiRequest("POST", "/api/cash-register", {
        type: "sale",
        amount: total.toFixed(2),
        notes: `Venda da Mesa ${tableId} - Pedido #${currentOrder.id}`,
      });

      await apiRequest("DELETE", `/api/tables/${tableId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tables/${tableId}/orders`] });
      queryClient.invalidateQueries({ queryKey: ["/api/cash-register"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      toast({
        title: "Pedido fechado",
        description: "O pedido foi fechado e a mesa foi liberada com sucesso.",
      });
    },
    onError: (error) => {
      console.error("Erro ao fechar pedido:", error);
      toast({
        title: "Erro",
        description: "Não foi possível fechar o pedido. Por favor, tente novamente.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="space-y-6 py-4">
      {!currentOrder ? (
        <Button
          onClick={() => createOrderMutation.mutate()}
          className="w-full"
        >
          Criar Novo Pedido
        </Button>
      ) : (
        <>
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Produto</Label>
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Pesquisar produto..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <div className="absolute w-full z-10 mt-1 bg-popover border rounded-md shadow-md max-h-48 overflow-y-auto">
                    {filteredProducts?.map((product: any) => (
                      <button
                        key={product.id}
                        className="w-full px-4 py-2 text-left hover:bg-accent hover:text-accent-foreground"
                        onClick={() => {
                          setSelectedProduct(String(product.id));
                          setSearchTerm("");
                        }}
                      >
                        {product.name} - R$ {Number(product.price).toFixed(2)}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Quantidade</Label>
              <Input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
            </div>

            <div className="flex items-end">
              <Button
                className="w-full"
                onClick={() => addItemMutation.mutate()}
                disabled={!selectedProduct || parseInt(quantity) < 1}
              >
                Adicionar Item
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold">Itens do Pedido</h3>
            <div className="space-y-2">
              {orderItems?.map((item: any) => {
                const product = products?.find((p: any) => p.id === item.productId);
                return (
                  <div
                    key={item.id}
                    className="flex justify-between items-center p-2 bg-secondary rounded-md"
                  >
                    <span>
                      {product?.name} x {item.quantity}
                    </span>
                    <div className="flex items-center gap-2">
                      <span>R$ {(item.quantity * Number(item.price)).toFixed(2)}</span>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={async () => {
                          try {
                            await apiRequest("DELETE", `/api/order-items/${item.id}`);
                            queryClient.invalidateQueries({ queryKey: [`/api/orders/${currentOrder?.id}/items`] });
                            toast({
                              title: "Item removido",
                              description: "O item foi removido do pedido.",
                            });
                          } catch (error) {
                            toast({
                              title: "Erro",
                              description: "Não foi possível remover o item.",
                              variant: "destructive",
                            });
                          }
                        }}
                      >
                        <Trash2Icon className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between items-center pt-4 border-t">
              <span className="font-semibold">Total:</span>
              <span className="font-semibold">
                R$
                {orderItems
                  ?.reduce(
                    (acc: number, item: any) =>
                      acc + item.quantity * Number(item.price),
                    0,
                  )
                  .toFixed(2) || "0.00"}
              </span>
            </div>

            <Button
              variant="default"
              className="w-full"
              onClick={() => closeOrderMutation.mutate()}
            >
              Fechar Pedido
            </Button>
          </div>
        </>
      )}
    </div>
  );
}