import { useQuery } from "@tanstack/react-query";
import TableGrid from "@/components/TableGrid";
import { Skeleton } from "@/components/ui/skeleton";

export default function Tables() {
  const { data: tables, isLoading } = useQuery({
    queryKey: ["/api/tables"],
  });

  if (isLoading) {
    return <Skeleton className="w-full h-[600px]" />;
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold tracking-tight">Tables</h1>
      <TableGrid tables={tables} />
    </div>
  );
}
