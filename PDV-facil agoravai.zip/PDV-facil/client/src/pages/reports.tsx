import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { DollarSign, TrendingUp, ShoppingBag } from "lucide-react";

export default function Reports() {
  const [timeframe, setTimeframe] = useState("today");

  // Obter dados de pedidos e caixa
  const { data: orders } = useQuery({
    queryKey: ["/api/orders"],
  });

  const { data: cashRegister } = useQuery({
    queryKey: ["/api/cash-register"],
  });

  // Filtrar dados baseado no período
  const filterByTimeframe = (date: Date) => {
    const now = new Date();
    switch (timeframe) {
      case "today":
        return (
          date.getDate() === now.getDate() &&
          date.getMonth() === now.getMonth() &&
          date.getFullYear() === now.getFullYear()
        );
      case "week":
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return date >= weekAgo;
      case "month":
        return (
          date.getMonth() === now.getMonth() &&
          date.getFullYear() === now.getFullYear()
        );
      default:
        return true;
    }
  };

  // Filtrar operações do período selecionado
  const filteredOrders = orders?.filter((order: any) =>
    filterByTimeframe(new Date(order.createdAt))
  );

  const filteredCashRegister = cashRegister?.filter((entry: any) =>
    filterByTimeframe(new Date(entry.createdAt))
  );

  // Calcular estatísticas
  const totalSales = filteredOrders?.reduce(
    (acc: number, order: any) => acc + Number(order.total),
    0
  ) || 0;

  const totalCashFlow = filteredCashRegister?.reduce(
    (acc: number, entry: any) => acc + Number(entry.amount),
    0
  ) || 0;

  const totalTransactions = filteredOrders?.length || 0;

  const averageOrderValue =
    totalTransactions > 0 ? totalSales / totalTransactions : 0;

  // Preparar dados do gráfico
  const salesByDay = filteredCashRegister?.reduce((acc: any, entry: any) => {
    const date = new Date(entry.createdAt).toLocaleDateString();
    if (entry.type === 'sale' || entry.type === 'withdrawal') {
      acc[date] = (acc[date] || 0) + Number(entry.amount);
    }
    return acc;
  }, {});

  const chartData = Object.entries(salesByDay || {}).map(([date, total]) => ({
    date,
    total,
  }));

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Relatórios</h1>
        <Select value={timeframe} onValueChange={setTimeframe}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Selecionar período" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Hoje</SelectItem>
            <SelectItem value="week">Últimos 7 dias</SelectItem>
            <SelectItem value="month">Este mês</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total em Vendas</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {totalSales.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total em Caixa
            </CardTitle>
            <ShoppingBag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {totalCashFlow.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Média por Pedido
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              R$ {averageOrderValue.toFixed(2)}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Movimentação por Período</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip 
                  formatter={(value: number) => [`R$ ${value.toFixed(2)}`, 'Total']}
                />
                <Bar dataKey="total" fill="hsl(var(--primary))" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Transações Recentes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {filteredCashRegister?.slice(0, 10).map((entry: any) => (
              <div
                key={entry.id}
                className="flex justify-between items-center p-2 bg-secondary rounded-md"
              >
                <div>
                  <p className="font-medium capitalize">
                    {entry.type === 'open' ? 'Abertura' :
                     entry.type === 'close' ? 'Fechamento' :
                     entry.type === 'sale' ? 'Venda' :
                     entry.type === 'withdrawal' ? 'Retirada' : entry.type}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(entry.createdAt).toLocaleString()}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {entry.notes || "Sem observações"}
                  </p>
                </div>
                <span className="font-semibold">
                  R$ {Number(entry.amount).toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}