import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useState } from "react";
import { Plus, Package } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Products() {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");

  const { data: products, isLoading } = useQuery({
    queryKey: ["/api/products"],
  });

  const createProductMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/products", {
        name,
        price: price,
        category,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setName("");
      setPrice("");
      setCategory("");
      toast({
        title: "Produto adicionado",
        description: "O produto foi adicionado com sucesso.",
      });
    },
    onError: (error) => {
      console.error("Erro ao criar produto:", error);
      toast({
        title: "Erro",
        description: "Não foi possível adicionar o produto. Por favor, tente novamente.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold tracking-tight">Produtos</h1>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">Novo Produto</CardTitle>
          </CardHeader>
          <CardContent>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                createProductMutation.mutate();
              }}
              className="space-y-4"
            >
              <div className="space-y-2">
                <Label>Nome do Produto</Label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: X-Burguer"
                />
              </div>

              <div className="space-y-2">
                <Label>Preço</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="0.00"
                />
              </div>

              <div className="space-y-2">
                <Label>Categoria</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lanches">Lanches</SelectItem>
                    <SelectItem value="bebidas">Bebidas</SelectItem>
                    <SelectItem value="porcoes">Porções</SelectItem>
                    <SelectItem value="sobremesas">Sobremesas</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={!name || !price || !category}
              >
                <Plus className="h-4 w-4 mr-2" />
                Adicionar Produto
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">Lista de Produtos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {products?.map((product: any) => (
                <div
                  key={product.id}
                  className="flex justify-between items-center p-2 bg-secondary rounded-md"
                >
                  <div className="flex items-center space-x-2">
                    <Package className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-muted-foreground capitalize">
                        {product.category}
                      </p>
                    </div>
                  </div>
                  <span className="font-semibold">
                    R$ {Number(product.price).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}