import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { DollarSign, Clock, ArrowUpDown } from "lucide-react";

export default function CashRegister() {
  const { toast } = useToast();
  const [amount, setAmount] = useState("");
  const [notes, setNotes] = useState("");
  const [paymentType, setPaymentType] = useState("");

  const { data: entries } = useQuery({
    queryKey: ["/api/cash-register"],
  });

  const { data: products } = useQuery({
    queryKey: ["/api/products"],
  });

  const createEntryMutation = useMutation({
    mutationFn: async () => {
      // Se for retirada, transforma o valor em negativo
      const finalAmount = paymentType === "withdrawal" ? 
        (-Math.abs(parseFloat(amount))).toString() : 
        amount;

      if (paymentType === "close") {
        // Registra o fechamento do caixa e limpa todas as transações
        await apiRequest("POST", "/api/cash-register", {
          type: "close",
          amount: "0",
          notes: `Fechamento de Caixa - ${new Date().toLocaleDateString()}`,
          clearTransactions: true
        });
      } else {
        // Para outros tipos de registro
        await apiRequest("POST", "/api/cash-register", {
          type: paymentType,
          amount: finalAmount,
          notes,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cash-register"] });
      setAmount("");
      setNotes("");
      setPaymentType("");
      toast({
        title: "Registro efetuado",
        description: paymentType === "close" 
          ? "O caixa foi fechado e um novo dia foi iniciado."
          : "O registro de caixa foi salvo com sucesso.",
      });
    },
    onError: (error) => {
      console.error("Erro ao registrar:", error);
      toast({
        title: "Erro",
        description: "Não foi possível registrar a operação. Por favor, tente novamente.",
        variant: "destructive",
      });
    },
  });

  // Obter entradas do dia
  const todayEntries = entries?.filter((entry: any) => {
    const entryDate = new Date(entry.createdAt);
    const today = new Date();
    return (
      entryDate.getDate() === today.getDate() &&
      entryDate.getMonth() === today.getMonth() &&
      entryDate.getFullYear() === today.getFullYear()
    );
  });

  const todayTotal = todayEntries?.reduce(
    (acc: number, entry: any) => acc + Number(entry.amount),
    0
  );

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold tracking-tight">Caixa</h1>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">Novo Registro</CardTitle>
          </CardHeader>
          <CardContent>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                createEntryMutation.mutate();
              }}
              className="space-y-4"
            >
              <div className="space-y-2">
                <Label>Tipo</Label>
                <Select value={paymentType} onValueChange={setPaymentType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Abrir Caixa</SelectItem>
                    <SelectItem value="close">Fechar Caixa</SelectItem>
                    <SelectItem value="sale">Venda</SelectItem>
                    <SelectItem value="withdrawal">Retirada</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {paymentType === "sale" && (
                <>
                  <div className="space-y-2">
                    <Label>Produto</Label>
                    <Select onValueChange={(value) => {
                      const product = products?.find(p => p.id === parseInt(value));
                      if (product) {
                        setAmount(product.price.toString());
                      }
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o produto" />
                      </SelectTrigger>
                      <SelectContent>
                        {products?.map((product) => (
                          <SelectItem key={product.id} value={product.id.toString()}>
                            {product.name} - R$ {Number(product.price).toFixed(2)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Valor</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="Digite o valor manualmente"
                    />
                  </div>
                </>
              )}
              {paymentType !== "close" && paymentType !== "sale" && (
                <div className="space-y-2">
                  <Label>Valor</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Digite o valor"
                  />
                </div>
              )}

              {paymentType !== "close" && (
                <div className="space-y-2">
                  <Label>Observações</Label>
                  <Input
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Observações adicionais"
                  />
                </div>
              )}

              <Button
                type="submit"
                className="w-full"
                disabled={paymentType === "" || (paymentType !== "close" && !amount)}
              >
                {paymentType === "close" ? "Fechar Caixa" : "Registrar"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">Resumo do Dia</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-2">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">Total</p>
                        <p className="text-2xl font-bold">
                          R$ {todayTotal?.toFixed(2) || "0,00"}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">Registros</p>
                        <p className="text-2xl font-bold">
                          {todayEntries?.length || 0}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <h3 className="font-semibold">Registros Recentes</h3>
                <div className="space-y-2">
                  {todayEntries?.slice(0, 5).map((entry: any) => (
                    <div
                      key={entry.id}
                      className="flex justify-between items-center p-2 bg-secondary rounded-md"
                    >
                      <div className="flex items-center space-x-2">
                        <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="font-medium capitalize">
                            {entry.type === 'open' ? 'Abertura' :
                              entry.type === 'close' ? 'Fechamento' :
                              entry.type === 'sale' ? 'Venda' :
                              entry.type === 'withdrawal' ? 'Retirada' : entry.type}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {entry.notes || "Sem observações"}
                          </p>
                        </div>
                      </div>
                      <span className="font-semibold">
                        R$ {Number(entry.amount).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}